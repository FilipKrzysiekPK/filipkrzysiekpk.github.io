#ifndef ELAPSED_TIMER_H
#define ELAPSED_TIMER_H

#include <chrono>

class ElapsedTimer {
    std::chrono::time_point<std::chrono::high_resolution_clock> startTime;
    std::chrono::nanoseconds elapsed = std::chrono::microseconds(0);
    std::chrono::nanoseconds timeSum = std::chrono::microseconds(0);
    unsigned amountOfElements = 0;

public:
    ElapsedTimer() = default;

    /**
     * Start measuring time
     */
    void start();

    /**
     * Stop measuring time. Add measured time to counted time
     */
    void stop();

    /**
     * Get average elapsed time in nanoseconds
     * @return nanoseconds
     */
    long long getAverageTimeInNs() const;

    /**
     * Get average elapsed time in microseconds
     * @return microseconds
     */
    long long getAverageTimeInUs() const;

    /**
     * Get average elapsed time in milliseconds
     * @return milliseconds
     */
    long long getAverageTimeInMs() const;

    /**
     * Reset data to calculate average time
     */
    void reset();

    /**
     * Get elapsed time in nanoseconds
     * @return nanoseconds
     */
    long long elapsedInNs() const;

    /**
     * Get elapsed time in microseconds
     * @return microseconds
     */
    long long elapsedInUs() const;

    /**
     * Get elapsed time in milliseconds
     * @return milliseconds
     */
    long long elapsedInMs() const;
};

#endif
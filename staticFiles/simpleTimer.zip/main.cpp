#include <random>
#include <iostream>

#include "ElapsedTimer.h"

using namespace std;

int main(int argc, char *argv[]) {
    //Initialize random
    std::random_device r;
    std::default_random_engine generator(r());
    std::uniform_real_distribution uniformDistr;

    // Usage example:
    double uniform = uniformDistr(generator);
}

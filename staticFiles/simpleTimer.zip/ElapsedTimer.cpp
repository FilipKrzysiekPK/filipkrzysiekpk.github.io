#include "ElapsedTimer.h"

void ElapsedTimer::start()
{
    startTime = std::chrono::high_resolution_clock::now();
}

void ElapsedTimer::stop()
{
    elapsed = std::chrono::high_resolution_clock::now() - startTime;
    timeSum += elapsed;
    ++amountOfElements;
}

long long ElapsedTimer::getAverageTimeInNs() const {
    return timeSum.count() / amountOfElements;
}

long long ElapsedTimer::getAverageTimeInUs() const {
    return std::chrono::duration_cast<std::chrono::microseconds>(elapsed).count() / amountOfElements;
}

long long ElapsedTimer::getAverageTimeInMs() const {
    return std::chrono::duration_cast<std::chrono::milliseconds>(elapsed).count() / amountOfElements;
}

void ElapsedTimer::reset() {
    elapsed = std::chrono::microseconds(0);
    timeSum = std::chrono::microseconds(0);
    amountOfElements = 0;
}

long long ElapsedTimer::elapsedInNs() const {
    return elapsed.count();
}

long long ElapsedTimer::elapsedInUs() const {
    return std::chrono::duration_cast<std::chrono::microseconds>(elapsed).count();
}

long long ElapsedTimer::elapsedInMs() const {
    return std::chrono::duration_cast<std::chrono::milliseconds>(elapsed).count();
}

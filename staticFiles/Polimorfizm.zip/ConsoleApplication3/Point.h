#pragma once
#include <iostream>

using namespace std;

class Point
{
	double* tab;
	unsigned size;

public:
	Point(unsigned dimmesnions): tab(new double[dimmesnions]), size(dimmesnions) {
		cout << "Point constructor" << endl;
	}

	Point(const Point& point) {
		tab = new double[point.size];

		size = point.size;

		for (unsigned i = 0; i < size; ++i) {
			tab[i] = point.tab[i];
		}
	}

	//Point(const Point& point) = default;

	Point(Point&& point) = delete;

	~Point() {
		cout << "Point destructor" << endl;
		delete[] tab;
	}
};


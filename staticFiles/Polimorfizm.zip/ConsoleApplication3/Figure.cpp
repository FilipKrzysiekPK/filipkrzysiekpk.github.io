#include "Figure.h"

Figure::Figure(const string &name): name(name)
{
	cout << "Figure constructor" << endl;
}

Figure::~Figure()
{
	cout << "Figure destructor" << endl;
}

void Figure::print()
{
	cout << name << endl;
}

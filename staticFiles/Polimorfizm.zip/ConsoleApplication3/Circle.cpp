#include "Circle.h"

Circle::Circle(const string& name, unsigned radius): Figure(name), radius(radius)
{
	cout << "Circle constructor" << endl;
}

Circle::~Circle()
{
	cout << "Circle destructor" << endl;
}

void Circle::setRadius(unsigned radius)
{
	this->radius = radius;
}

void Circle::print()
{
	Figure::print();
	cout << name << " readius: " << radius << endl;
}

double Circle::getObw()
{
	return 3.1415 * radius * 2;
}

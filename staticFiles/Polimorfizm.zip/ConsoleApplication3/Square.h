#pragma once
#include "Figure.h"

class Square: public Figure
{
	double a;

public:
	Square(const string& name, double a) : Figure(name), a(a) {

	}

	double getObw() override {
		return a * 4;
	}
};


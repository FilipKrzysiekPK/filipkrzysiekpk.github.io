#pragma once
#include "Figure.h"
class Circle : public Figure
{
	unsigned radius;

public:
	Circle(const string& name, unsigned radius);
	virtual ~Circle();

	void setRadius(unsigned radius);

	void print() override;

	double getObw() override;
};


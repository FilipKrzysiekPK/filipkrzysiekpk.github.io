#pragma once
#include <iostream>

using namespace std;

class Figure
{
protected:
	string name;

public:
	Figure(const string& name);

	virtual ~Figure();

	virtual void print();

	virtual double getObw() = 0;
};


﻿

#include <iostream>
#include "Point.h"
#include "Circle.h"
#include "Square.h"
#include <vector>

using namespace std;

int main()
{
    //Point p1(5);
    //Point p2 = p1;
    //Point p3(p1);

    //cout << "-------------------------" << endl;

    //Circle square("test circle", 50);
    ////Figure fig("test");

    //cout << "-------------------------" << endl;

    ////fig.print();
    //square.print();
    //square.setRadius(150);

    //Figure* pf1 = &square;
    Figure* pf2 = new Circle("Polimorfizm", 120);

    //pf1->print();
    //pf2->print();

    //Square trueSquare("I'm square", 190);

    //vector<Figure*> figures;
    //figures.push_back(&square);
    //figures.push_back(&trueSquare);

    //for (auto& fig : figures) {
    //    fig->print();
    //    cout << fig->getObw() << endl;
    //}


    cout << "-------------------------" << endl;
    delete pf2;

    return 0;
}
